/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ui;

/**
 *
 * @author tanujamahajan
 */
public class AddPerson {
     String nuid;
     String fullname;
     String gender;
     String department;
     String address;

   public AddPerson(String nuid, String fullname, String gender, String department, String address)
   {
       this.nuid = nuid;
       this.fullname = fullname;
       this.gender = gender;
       this.department = department;
       this.address = address;
   }
}
