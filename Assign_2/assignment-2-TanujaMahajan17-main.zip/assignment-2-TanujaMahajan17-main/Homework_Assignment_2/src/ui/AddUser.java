/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ui;

import java.util.ArrayList;

/**
 *
 * @author tanujamahajan
 */
public class AddUser {
     String nuid;
     String username;
     String password;
     String role;
     String status;
     ArrayList<String> passwordHistory = new ArrayList<>();
             
   public AddUser(String nuid, String username, String password, String role, String status, String passwordhistroy)
   {
       this.nuid = nuid;
       this.username = username;
       this.password = password;
       this.role = role;
       this.status = status;
       this.passwordHistory.add(passwordhistroy);
   }
}
